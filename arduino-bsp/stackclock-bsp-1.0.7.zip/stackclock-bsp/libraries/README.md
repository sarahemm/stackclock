The libraries in this folder come from watterott's ATmega328PB Arduino support at https://github.com/watterott/ATmega328PB-Testing
